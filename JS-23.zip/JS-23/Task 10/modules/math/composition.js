import { multiplication, substraction } from './multiplication';

export default function composition(a, b) {
  return multiplication(a, b) + substraction(a, b);
}
