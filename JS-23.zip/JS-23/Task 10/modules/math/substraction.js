export default function substraction(a, b) {
  return a - b;
}
