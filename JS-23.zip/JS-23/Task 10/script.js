/* ------------------------------ TASK 9 ---------------------------------------------------
Sutvarkykite užduoties "Task 10" esančius failus taip, kad veiktų žemiau pateiktos funcijos
--
------------------------------------------------------------------------------------------ */
import  composition   from './composition.js';
import  multiplication  from './multiplication.js';
import  substraction  from './substractiony.js';
import  division  from './division.js';
// import { one, two, three, four, five } from './numbers.js';

let one = 1;
let two = 2;
let three = 3;
let four = 4;
let five = 5;

let a = composition(one, four);
let b = division(four, two);
let c = substraction(three, two);
let d = multiplication(five, two);

console.log(a);
console.log(b);
console.log(c);
console.log(c);
