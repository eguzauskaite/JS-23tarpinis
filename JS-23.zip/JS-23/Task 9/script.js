/* ------------------------------ TASK 9 ---------------------------------------------------------------
Sukurkite konstruktoriaus funkciją "Movie" (naudokte ES6), kuri sukuria objektus 3 savybėm ir 1 metodu. Tuomet, atspausdinkite du filmus,
kurių vienas duotų false, kitas true ir atspausdintų atitinkamus variantus. Pvz., 
"Avengers: Endgame" biudžetas viršyjo 100 mln. USD
"Mr. Nobody" biudžetas neviršyjo 100 mln. USD

Savybės:
title, director, budget
Metodas: 
wasExpensive() - jeigu filmo budget bus didesnę nei 100 000 000 mln USD, tada gražins true, kiru atveju false 
------------------------------------------------------------------------------------------------------ */

class Movie {
    constructor(title, director, budget) {
      this.title = title;
      this.director = director;
      this.budget = budget;
    }
  
   
    wasExpensive() {
      return this.budget > 100000000;
    }
  }
  
  
  const avengersEndgame = new Movie('Avengers: Endgame', 'Directors', 200000000);
  const mrNobody = new Movie('Mr. Nobody', 'Some Director', 80000000);
  
  
  console.log(`${avengersEndgame.title} budget exceeded 100 mln. USD: ${avengersEndgame.wasExpensive() ? 'true' : 'false'}`);
  console.log(`${mrNobody.title} budget not exceeded 100 mln. USD: ${mrNobody.wasExpensive() ? 'true' : 'false'}`);