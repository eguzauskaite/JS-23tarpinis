/* ------------------------------ TASK 3 -----------------------------------
Parašykite JS kodą, kuris leis vartotojui paspaudus ant mygtuko "Show users"
pamatyti vartotojus iš Github API (endpoint'as pateiktas žemiau).

Paspaudus mygtuką "Show users":
1. Pateikiamas informacijos atvaizdavimas <div id="output"></div> bloke
1.1. Infrmacija, kuri pateikiama: "login" ir "avatar_url" reikšmės (kortelėje)
2. Žinutė "Press "Show Users" button to see users" turi išnykti;
"
Pastaba: Informacija apie user'į (jo kortelė) bei turi turėti bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = 'https://api.github.com/users';

document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('btn');
    const outputDiv = document.getElementById('output');
    const message = document.getElementById('message');
  
    btn.addEventListener('click', function () {
      
      getUsersFromGithub();
    });
  
    function getUsersFromGithub() {
     
      outputDiv.innerHTML = '';
  
      
      fetch(ENDPOINT)
        .then((response) => response.json())
        .then((users) => {
         
          users.forEach((user) => {
            const userCard = createUserCard(user);
            outputDiv.appendChild(userCard);
          });
  
          
          message.style.display = 'none';
        })
        .catch((error) => {
         
          outputDiv.innerHTML = `<p class="error-message">Error fetching GitHub users: ${error.message}</p>`;
        });
    }
  
    function createUserCard(user) {
      
      const userCard = document.createElement('div');
      userCard.classList.add('user-card');
  
      const login = document.createElement('p');
      login.textContent = `Login: ${user.login}`;
  
      const avatar = document.createElement('img');
      avatar.src = user.avatar_url;
      avatar.alt = `Avatar of ${user.login}`;
  
      userCard.appendChild(login);
      userCard.appendChild(avatar);
  
      return userCard;
    }
  });