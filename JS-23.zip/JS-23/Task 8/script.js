/* ------------------------------ TASK 8 --------------------------------------------
Sukurkite konstruktoriaus funkciją "Calculator" (naudokite ES5), kuri sukuria objektus su 3 metodais:
sum() - priima du skaičius ir grąžina jų sumą.
subtraction() - priima du skaičius ir grąžina jų skirtumą.
multiplication() - priima du skaičius ir grąžina jų daugybos rezultatą;
division() - priima du skaičius ir grąžina jų dalybos rezultatą;
------------------------------------------------------------------------------------ */

function Calculator() {
    
    this.sum = function (a, b) {
      return a + b;
    };
  
    this.subtraction = function (a, b) {
      return a - b;
    };
  
    
    this.multiplication = function (a, b) {
      return a * b;
    };
  
   
    this.division = function (a, b) {
      
      if (b !== 0) {
        return a / b;
      } else {
        
        return 'Dalyba iš nulio negalima';
      }
    };
  }
 
  var calculator = new Calculator();
  
  
  console.log('Suma:', calculator.sum(12, 63)); 
  console.log('Skirtumas:', calculator.subtraction(255, 55)); 
  console.log('Daugyba:', calculator.multiplication(20, 25)); 
  console.log('Dalyba:', calculator.division(600, 3)); 
  console.log('Dalyba iš nulio:', calculator.division(88, 0));