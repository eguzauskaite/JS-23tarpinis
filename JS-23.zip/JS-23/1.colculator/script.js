/* ------------------------------ TASK 1 ----------------------------
Parašykite JS kodą, kuris leis vartotojui įvesti svorį kilogramais ir
pamatyti jo pateikto svorio kovertavimą į:
1. Svarus (lb) | Formulė: lb = kg * 2.2046
2. Gramus (g) | Formulė: g = kg / 0.0010000
3. Uncijos (oz) | Formul4: oz = kg * 35.274

Pastaba: atvaizdavimas turi būti matomas pateikus formą ir pateikiamas
<div id="output"></div> viduje, bei turi turėti bent minimalų stilių;
------------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function () {
   
    const form = document.querySelector("form");
    const outputDiv = document.getElementById("output");

    
    form.addEventListener("submit", function (e) {
      
      e.preventDefault();

      
      const inputWeight = document.getElementById("search").value;

     
      if (!isNaN(inputWeight) && inputWeight !== "") {
        
        const weightInKg = parseFloat(inputWeight);
        const weightInLb = weightInKg * 2.2046;
        const weightInG = weightInKg / 0.001;
        const weightInOz = weightInKg * 35.274;

        const resultHTML = `
          <p><strong>Svoris:</strong> ${inputWeight} kg</p>
          <p><strong>Svarai:</strong> ${weightInLb.toFixed(2)} lb</p>
          <p><strong>Gramai:</strong> ${weightInG.toFixed(2)} g</p>
          <p><strong>Uncijos:</strong> ${weightInOz.toFixed(2)} oz</p>
        `;

       
        outputDiv.innerHTML = resultHTML;
      } else {
        
        outputDiv.innerHTML = "<p>Įveskite teisingą skaičių svorio laukelyje.</p>";
      }
    });
  });