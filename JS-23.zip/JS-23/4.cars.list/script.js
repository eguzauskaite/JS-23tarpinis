/* ------------------------------ TASK 4 -----------------------------------
Parašykite JS kodą, vartotojui atėjus į tinklapį kreipsis į cars.json failą
ir iš jo atvaizduos visus automobilių gamintojus ir pagamintus modelius. 
Kiekvienas gamintojas turės savo atvaizdavimo "kortelę", kurioje bus 
nurodomas gamintojas ir jo pagaminti modeliai.


Pastaba: Informacija apie automobilį (brand) (jo kortelė) bei turi turėti 
bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = 'cars.json';

async function fetchData(url) {
    try {
      const response = await fetch(url);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
  
  
  function createCard(brandData) {
    const card = document.createElement('div');
    card.classList.add('card');
  
    const brandHeader = document.createElement('h2');
    brandHeader.textContent = brandData.brand;
  
    const modelList = document.createElement('ul');
    brandData.models.forEach((model) => {
      const listItem = document.createElement('li');
      listItem.textContent = model;
      modelList.appendChild(listItem);
    });
  
    card.appendChild(brandHeader);
    card.appendChild(modelList);
  
    return card;
  }
  
 
  function displayCards(carsData) {
    const outputDiv = document.getElementById('output');
  
    carsData.forEach((brandData) => {
      const card = createCard(brandData);
      outputDiv.appendChild(card);
    });
  }
  
  
  async function init() {
    const carsData = await fetchData(ENDPOINT);
    if (carsData) {
      displayCards(carsData);
    }
  }
  
  
  document.addEventListener('DOMContentLoaded', init);
